# kelmscott-mono

A blackletter for the text editor. Inspired by Morris Troy and Morris Roman. Built for legibility in the IDE.

## Samples

!["Aa / Kelmscott Mono"](samples/1.png)

!["A blackletter for the text editor. Inspired by Morris Troy and Morris Roman. Built for legibility in the IDE."](samples/2.png)

![Punctuation and special characters](samples/3.png)

![A React code listing](samples/4.jpg)
